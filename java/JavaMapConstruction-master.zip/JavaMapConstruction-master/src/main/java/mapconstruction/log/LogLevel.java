package mapconstruction.log;

/**
 * @author Roel
 */
public enum LogLevel {
    STATUS,
    INFO,
    WARNING,
    ERROR
}
