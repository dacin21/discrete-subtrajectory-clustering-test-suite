package mapconstruction.GUI.listeners;

/**
 * Listener for changes to filters
 *
 * @author Roel
 */
public interface FilterChangeListener {


    void filterChanged(FilterChangeEvent evt);

}
