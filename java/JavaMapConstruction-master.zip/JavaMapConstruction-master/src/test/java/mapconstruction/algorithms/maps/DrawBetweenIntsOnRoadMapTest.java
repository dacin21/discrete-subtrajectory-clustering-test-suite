package mapconstruction.algorithms.maps;

import mapconstruction.TestUtil;
import org.junit.*;

import java.awt.geom.Point2D;
import java.util.List;

/**
 * @Author Jorrick Sleijster
 */
public class DrawBetweenIntsOnRoadMapTest {


    public DrawBetweenIntsOnRoadMapTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of the FindBestMerge.. Produces weird results
     */
    @Test
    public void testFindBestMerge(){

        List<Point2D> points;
    }
}
